package com.example.resep_makanan_14195

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
