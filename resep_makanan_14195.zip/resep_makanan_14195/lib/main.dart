// main.dart
import 'package:flutter/material.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';  // Import sqflite_common_ffi
import 'layar/beranda_layar.dart';

void main() {
  // Inisialisasi database factory untuk FFI
  databaseFactory = databaseFactoryFfi;

  runApp(AplikasiResep());
}

class AplikasiResep extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pengelola Resep',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: BerandaLayar(),
    );
  }
}
