// Model/resep.dart
class Resep {
  int? id;
  String nama;
  String waktuPersiapan;
  String bahan;
  String langkah;

  Resep({
    this.id,
    required this.nama,
    required this.waktuPersiapan,
    required this.bahan,
    required this.langkah,
  });

  // Konversi dari Map ke objek Resep
  factory Resep.dariMap(Map<String, dynamic> map) {
    return Resep(
      id: map['id'],
      nama: map['nama'],
      waktuPersiapan: map['waktu_persiapan'],
      bahan: map['bahan'],
      langkah: map['langkah'],
    );
  }

  // Konversi dari objek Resep ke Map
  Map<String, dynamic> keMap() {
    return {
      'id': id,
      'nama': nama,
      'waktu_persiapan': waktuPersiapan,
      'bahan': bahan,
      'langkah': langkah,
    };
  }
}
