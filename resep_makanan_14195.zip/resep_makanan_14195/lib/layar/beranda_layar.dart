// Layar/beranda_layar.dart
import 'package:flutter/material.dart';
import 'package:resep_makanan_14195/Db/database_helper.dart';
import 'detail_resep_layar.dart'; // Pastikan ini ada jika ingin menavigasi ke detail resep
import 'tambah_resep_layar.dart'; // Pastikan ini ada jika ingin menavigasi ke tambah resep

class BerandaLayar extends StatefulWidget {
  const BerandaLayar({Key? key}) : super(key: key);

  @override
  _BerandaLayarState createState() => _BerandaLayarState();
}

class _BerandaLayarState extends State<BerandaLayar> {
  late Future<List<Map<String, dynamic>>> _resepList;

  @override
  void initState() {
    super.initState();
    _resepList = DatabaseHelper.instance.ambilResep(); // Memanggil metode ambilResep dari DatabaseHelper
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Resep'),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              // Navigasi ke halaman tambah resep
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const TambahResepLayar()),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>( // Menggunakan FutureBuilder untuk menunggu data resep
        future: _resepList,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator()); // Menunggu data
          } else if (snapshot.hasError) {
            return Center(child: Text('Terjadi kesalahan: ${snapshot.error}')); // Menangani error
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Tidak ada resep')); // Menampilkan jika data kosong
          } else {
            final resepList = snapshot.data!;
            return ListView.builder(
              itemCount: resepList.length,
              itemBuilder: (context, index) {
                final resep = resepList[index];
                return ListTile(
                  title: Text(resep['name']), // Menampilkan nama resep
                  subtitle: Text(resep['preparation_time']), // Menampilkan waktu persiapan resep
                  onTap: () {
                    // Navigasi ke halaman DetailResepLayar
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailResepLayar(id: resep['id']),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
