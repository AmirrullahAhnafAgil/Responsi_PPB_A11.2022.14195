// layar/tambah_resep_layar.dart
import 'package:flutter/material.dart';
import 'package:resep_makanan_14195/Db/database_helper.dart'; // Jika perlu, sesuaikan dengan penggunaan

class TambahResepLayar extends StatefulWidget {
  const TambahResepLayar({Key? key}) : super(key: key);

  @override
  _TambahResepLayarState createState() => _TambahResepLayarState();
}

class _TambahResepLayarState extends State<TambahResepLayar> {
  final _formKey = GlobalKey<FormState>();
  String nama = '';
  String waktuPersiapan = '';
  String bahan = '';
  String langkah = '';

  void _simpanResep() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      // Simpan resep ke database (gunakan toMap untuk konversi ke Map)
      final resepBaru = Resep(
        nama: nama,
        waktuPersiapan: waktuPersiapan,
        bahan: bahan,
        langkah: langkah,
      );
      DatabaseHelper.instance.tambahResep(resepBaru.toMap()); // Mengirim Map ke fungsi
      Navigator.pop(context); // Kembali ke layar sebelumnya setelah simpan
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Resep'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              TextFormField(
                decoration: const InputDecoration(labelText: 'Nama Resep'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama resep tidak boleh kosong';
                  }
                  return null;
                },
                onSaved: (value) {
                  nama = value!;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Waktu Persiapan'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Waktu persiapan tidak boleh kosong';
                  }
                  return null;
                },
                onSaved: (value) {
                  waktuPersiapan = value!;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Bahan'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Bahan tidak boleh kosong';
                  }
                  return null;
                },
                onSaved: (value) {
                  bahan = value!;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Langkah'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Langkah tidak boleh kosong';
                  }
                  return null;
                },
                onSaved: (value) {
                  langkah = value!;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _simpanResep,
                child: const Text('Simpan Resep'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Resep {
  final String nama;
  final String waktuPersiapan;
  final String bahan;
  final String langkah;

  Resep({
    required this.nama,
    required this.waktuPersiapan,
    required this.bahan,
    required this.langkah,
  });

  // Menambahkan metode untuk mengonversi Resep ke Map
  Map<String, dynamic> toMap() {
    return {
      'name': nama,
      'preparation_time': waktuPersiapan,
      'ingredients': bahan,
      'instructions': langkah,
    };
  }
}
