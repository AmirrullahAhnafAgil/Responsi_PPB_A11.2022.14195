// layar/detail_resep_layar.dart
import 'package:flutter/material.dart';
import 'package:resep_makanan_14195/Db/database_helper.dart';

class DetailResepLayar extends StatefulWidget {
  final int id;
  const DetailResepLayar({Key? key, required this.id}) : super(key: key);

  @override
  _DetailResepLayarState createState() => _DetailResepLayarState();
}

class _DetailResepLayarState extends State<DetailResepLayar> {
  late Future<Map<String, dynamic>?> _resepDetail;

  @override
  void initState() {
    super.initState();
    _resepDetail = DatabaseHelper.instance.ambilResepById(widget.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Resep'),
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _resepDetail,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return const Center(child: Text('Terjadi kesalahan'));
          } else if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text('Detail resep tidak ditemukan'));
          } else {
            final resep = snapshot.data!;
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Nama: ${resep['name']}', style: const TextStyle(fontSize: 22)),
                  Text('Waktu Persiapan: ${resep['preparation_time']}'),
                  Text('Bahan-bahan: ${resep['ingredients']}'),
                  Text('Instruksi: ${resep['instructions']}'),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
